package com.motorph.payroll.model;


public interface Payable {
    double calculateSalary();
}
